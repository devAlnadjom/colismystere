<template>
  <div v-if="links.length > 3">
    <div class="flex flex-wrap -mb-1">
      <template v-for="(link, key) in links">
        <div v-if="link.url === null" :key="key" class="mr-1 mb-1 px-2 py-1 text-sm leading-4 text-gray-400 border rounded" v-html="link.label" />
        <Link v-else :key="key + 1" class="mr-1 mb-1 px-2 py-1 text-sm leading-4 border rounded hover:bg-pink-100 focus:border-pink-400 focus:text-pink-500" :class="{ 'text-pink-600 bg-pink-100 hover:bg-pink-200': link.active }" :href="link.url" v-html="link.label" />
      </template>
    </div>
  </div>
</template>

<script>
import { Link } from "@inertiajs/inertia-vue3";

export default {
  components: {
    Link,
  },
  props: {
    links: Array,
  },
}
</script>
